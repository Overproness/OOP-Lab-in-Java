public class Dog extends Animal {
    String breed;

    public void setName(String _name){
        name=_name;
    }

    public void setBreed(String _setBreed){
        breed=_setBreed;
    }

    public void speak(){
        System.out.println("A dog barks. ");
    }
}
