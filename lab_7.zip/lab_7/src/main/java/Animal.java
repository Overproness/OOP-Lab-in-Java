public class Animal {
    String name;

    public void speak(){
        System.out.println("An animal makes a sound. ");
    }
}
