public class Main {
    public static void main(String[] args) {
        Dog myDog=new Dog();
        myDog.setName("Buddy");
        myDog.setBreed("Golden Retriever");
        myDog.speak();
    }
}
