package lab;
public class BankAccount {
    public static int accNo;
    private String accHolderName;
    private String accType;
    private int balance;

    BankAccount(String _accHolderName){
        this(_accHolderName, accNo++,0);
    }

    BankAccount(String _accHolderName,int _accNo,int _balance){
        this(_accHolderName,accNo++,_balance,"");
    }

    BankAccount(String _accHolderName, int _accNo, int _balance, String _accType){
        accHolderName = _accHolderName;
        accNo=_accNo;
        balance=_balance;
        accType=_accType;
    }

    public void displayInfo(){
        System.out.println(accNo);
        System.out.println(accHolderName);
        System.out.println(accType);
        System.out.println(balance);
    }

    public static void main(String[] args) {
        BankAccount ba1=new BankAccount("Ahmed Mabood",1,-200,"Donations");
        ba1.displayInfo();
    }
}
