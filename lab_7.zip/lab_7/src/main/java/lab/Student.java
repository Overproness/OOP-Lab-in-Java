package lab;

public class Student {
    static int id;
    String name;
    int age;
    String course;

    public Student(String _name){
        this(id++,_name,"");
    }

    public Student(int _id, String _name, String _course){
        this(_id,_name,_course,0);
    }

    public Student(int _id, String _name, String _course, int _age){
        id=_id;
        name=_name;
        course=_course;
        age=_age;
    }

    public void displayInfo(){
        System.out.println(name);
        System.out.println(age);
        System.out.println(id);
        System.out.println(course);
    }

    public static void main(String[] args) {
        Student std1=new Student(1,"Ahmed Mabood","Ulti Harkaten karna",200);
        std1.displayInfo();
    }
}
